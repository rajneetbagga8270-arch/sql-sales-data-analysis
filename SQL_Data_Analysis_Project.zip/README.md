# SQL Data Analysis Project

## Project Overview
A MySQL sales analytics project covering data cleaning, exploratory analysis, business KPIs, customer analysis and advanced SQL.

## Tools
- MySQL
- SQL
- JOINs
- Aggregate functions
- CTEs
- Window functions

## Dataset
500 sales transactions from 2025 with intentional data-quality issues for cleaning practice.

## Analysis
- Overall revenue, orders, customers and units sold
- Revenue by region, product and category
- Monthly revenue trends
- Top customers
- Revenue share by region
- Product ranking
- Ranking within categories
- Cumulative revenue
- Month-over-month growth
- Top product in each region

## Files
- `Sales_Data_Analysis_Project.sql` — complete MySQL script
- `sql_sales_raw_data.csv` — raw dataset

## Resume Version
**SQL Data Analysis Project**
- Wrote SQL queries for data cleaning and analysis using MySQL.
- Used JOINs, aggregate functions, CTEs and window functions to analyze sales and customer data.
- Generated insights on revenue, product performance, regional trends and monthly growth.
